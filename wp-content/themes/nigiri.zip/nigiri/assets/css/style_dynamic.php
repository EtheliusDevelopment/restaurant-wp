<?php

do_action('nigiri_elated_action_style_dynamic');