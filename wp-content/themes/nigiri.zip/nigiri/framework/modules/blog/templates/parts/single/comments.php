<?php
if(nigiri_elated_show_comments()){
    comments_template('', true);
}