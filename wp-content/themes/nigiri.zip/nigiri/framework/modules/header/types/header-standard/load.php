<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard/header-standard.php';