<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/social-icons-group/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/social-icons-group/social-icons-group.php';