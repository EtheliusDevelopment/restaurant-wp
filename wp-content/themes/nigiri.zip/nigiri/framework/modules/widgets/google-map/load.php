<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/google-map/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/google-map/google-map.php';