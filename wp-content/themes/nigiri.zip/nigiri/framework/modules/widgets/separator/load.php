<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/separator/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/separator/separator.php';