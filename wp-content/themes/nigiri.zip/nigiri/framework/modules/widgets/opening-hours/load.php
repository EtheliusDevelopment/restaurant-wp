<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/opening-hours/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/opening-hours/opening-hours.php';