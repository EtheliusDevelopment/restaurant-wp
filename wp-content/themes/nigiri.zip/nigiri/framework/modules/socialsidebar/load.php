<?php
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/socialsidebar/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/socialsidebar/options-map/map.php';