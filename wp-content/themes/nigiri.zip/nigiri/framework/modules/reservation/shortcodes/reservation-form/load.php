<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/reservation/shortcodes/reservation-form/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/reservation/shortcodes/reservation-form/reservation-form.php';
