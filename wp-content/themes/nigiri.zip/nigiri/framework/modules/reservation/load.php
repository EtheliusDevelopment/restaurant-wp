<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/reservation/options-map/map.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/reservation/reservation-functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/reservation/shortcodes/shortcodes-functions.php';