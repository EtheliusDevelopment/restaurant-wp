<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/subscribe-popup/functions.php';

//load global subscribe popup options
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/subscribe-popup/options-map/subscribe-popup-map.php';
