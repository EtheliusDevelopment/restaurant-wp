<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/title/types/centered/functions.php';