<div class="eltdf-content-bottom" <?php nigiri_elated_inline_style( $content_bottom_style ); ?>>
	<div class="eltdf-content-bottom-inner <?php echo esc_attr( $grid_class ); ?>">
		<?php dynamic_sidebar( $content_bottom_area_sidebar ); ?>
	</div>
</div>