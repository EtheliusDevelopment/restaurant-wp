<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/content-bottom/functions.php';

//load global content bottom options
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/content-bottom/admin/options-map/content-bottom-map.php';

//load per page content bottom options
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/content-bottom/admin/meta-boxes/content-bottom-meta-boxes.php';