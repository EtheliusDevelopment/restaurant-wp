<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

<!--
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Maleah-Regular.woff" as="font" type="font/woff" crossorigin>
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Maleah-Bold.woff" as="font" type="font/woff" crossorigin>
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Maleah-Light.woff" as="font" type="font/woff" crossorigin> 
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Maleah-Oblique.woff" as="font" type="font/woff" crossorigin> 
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Brooklyn-Normal.woff2" as="font" type="font/woff2" crossorigin> 
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Brooklyn-Bold.woff2" as="font" type="font/woff2" crossorigin> 
  <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Brooklyn-Heavy.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="https://www.izumilano.com/wp-content/themes/nigiri-child/fonts/Brooklyn-SemiBold.woff2" as="font" type="font/woff2" crossorigin>  -->
	<?php
	/**
	 * nigiri_elated_action_header_meta hook
	 *
	 * @see nigiri_elated_header_meta() - hooked with 10
	 * @see nigiri_elated_user_scalable_meta - hooked with 10
	 * @see nigiri_core_set_open_graph_meta - hooked with 10
	 */
	do_action( 'nigiri_elated_action_header_meta' );
	
	wp_head(); ?>



<script type="text/javascript">var _iub = _iub || {}; _iub.cons_instructions = _iub.cons_instructions || []; _iub.cons_instructions.push(["init", {api_key: "ljLaUyNcIBoYyFemo6fHysle8IUBIUJb"}]);</script><script type="text/javascript" src="https://cdn.iubenda.com/cons/iubenda_cons.js" async></script>
	
	  <script type="text/javascript">
        var _iub = _iub || [];
        _iub.csConfiguration = {
            "lang": "it",
            "siteId": 1902318, //usa il tuo siteId
            "cookiePolicyId": 68130548, //usa il tuo cookiePolicyId
            "banner": {
                "position": "float-top-center",
                "acceptButtonDisplay": true,
                "customizeButtonDisplay": true
            }
        };
    </script>
    <script type="text/javascript" src="//cdn.iubenda.com/cs/iubenda_cs.js" charset="UTF-8" async></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167290507-1"></script>

<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-167290507-1');
</script>
	
	
	  <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri();?>/slick/slick.css">
  	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri();?>/slick/slick-theme.css">
	<script src="https://kit.fontawesome.com/c706eaa611.js" crossorigin="anonymous"></script>
</head>
<body <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">
	<?php
	/**
	 * nigiri_elated_action_after_body_tag hook
	 *
	 * @see nigiri_elated_get_side_area() - hooked with 10
	 * @see nigiri_elated_smooth_page_transitions() - hooked with 10
	 */
	do_action( 'nigiri_elated_action_after_body_tag' ); ?>
<div class="topbar1">
	L'EMOZIONE DEL SUSHI DIRETTAMENTE A CASA TUA - <a href="https://www.izumilano.com/menu-sushi-alla-carta/">ORDINA QUI</a>
	</div>
    <div class="eltdf-wrapper">
        <div class="eltdf-wrapper-inner">
            <?php
            /**
             * nigiri_elated_action_after_wrapper_inner hook
             *
             * @see nigiri_elated_get_header() - hooked with 10
             * @see nigiri_elated_get_mobile_header() - hooked with 20
             * @see nigiri_elated_back_to_top_button() - hooked with 30
             * @see nigiri_elated_get_header_minimal_full_screen_menu() - hooked with 40
             * @see nigiri_elated_get_header_bottom_navigation() - hooked with 40
             */
            do_action( 'nigiri_elated_action_after_wrapper_inner' ); ?>
	        
            <div class="eltdf-content" <?php nigiri_elated_content_elem_style_attr(); ?>>
                <div class="eltdf-content-inner">
					
					
					<script>
					
						jQuery(function() {
							curpage = window.location.href ;
    				if(curpage.includes("product"))
						{
							console.log("page product");
						jQuery("div[id^='product-']").attr("style","width:80% !important; margin-left:10% !important");
						}
							
							
							
						});

						
						jQuery(function($) {
						

							$(document).ready(function() {


							
							$('.eltdf-accordion-title.ui-accordion-header.ui-state-default').click( function(e){
								$('.eltdf-accordion-title').removeClass('ui-accordion-header-active');
								$('.eltdf-accordion-title').removeClass('ui-state-active');
								$(this).addClass('ui-accordion-header-active');
								$(this).addClass('ui-state-active');
								$(".eltdf-accordion-content.ui-accordion-content.ui-helper-reset.ui-widget-content.ui-corner-bottom").css({"display": "none"});
  $(this).next().css({"display": "block"});
});
								
	

							});

					



						});
						var $ = window.jQuery;
					</script>
					
					
					<style>
						
					</style>