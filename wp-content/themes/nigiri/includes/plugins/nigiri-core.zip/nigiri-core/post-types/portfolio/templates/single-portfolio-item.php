<?php

get_header();

nigiri_elated_get_title();

do_action('nigiri_elated_action_before_main_content');

nigiri_core_get_single_portfolio();

get_footer();