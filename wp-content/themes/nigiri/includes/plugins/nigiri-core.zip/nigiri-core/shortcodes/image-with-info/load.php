<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/image-with-info/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/image-with-info/image-with-info.php';