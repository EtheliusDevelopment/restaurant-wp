<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/opening-hours/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/opening-hours/opening-hours.php';