<div class="eltdf-clients-carousel-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="eltdf-cc-inner eltdf-owl-slider" <?php echo nigiri_elated_get_inline_attrs($carousel_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>