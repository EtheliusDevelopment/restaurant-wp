<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/dual-image-showcase/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/dual-image-showcase/dual-image-showcase.php';