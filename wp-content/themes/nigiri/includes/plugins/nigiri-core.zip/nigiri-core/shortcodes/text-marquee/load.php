<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/text-marquee/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/text-marquee/text-marquee.php';