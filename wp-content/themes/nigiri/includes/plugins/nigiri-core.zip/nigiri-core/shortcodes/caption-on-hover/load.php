<?php

include_once NIGIRI_CORE_SHORTCODES_PATH.'/caption-on-hover/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH.'/caption-on-hover/caption-on-hover.php';