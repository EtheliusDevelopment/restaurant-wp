<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/clients-grid/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/clients-grid/clients-grid.php';