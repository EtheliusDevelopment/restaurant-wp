<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/call-to-action/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/call-to-action/call-to-action.php';