<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/vertical-image-info/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/vertical-image-info/vertical-image-info.php';