<?php

include_once NIGIRI_CORE_SHORTCODES_PATH.'/circle-carousel/circle-carousel.php';
include_once NIGIRI_CORE_SHORTCODES_PATH.'/circle-carousel/functions.php';