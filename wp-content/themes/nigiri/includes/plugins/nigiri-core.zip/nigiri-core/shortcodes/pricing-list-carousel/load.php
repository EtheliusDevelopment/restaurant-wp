<?php

include_once NIGIRI_CORE_SHORTCODES_PATH . '/pricing-list-carousel/functions.php';
include_once NIGIRI_CORE_SHORTCODES_PATH . '/pricing-list-carousel/pricing-list-carousel.php';