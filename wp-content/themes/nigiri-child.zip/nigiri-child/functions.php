<?php

/*** Child Theme Function  ***/

if ( ! function_exists( 'nigiri_elated_child_theme_enqueue_scripts' ) ) {
	function nigiri_elated_child_theme_enqueue_scripts() {
		$parent_style = 'nigiri-elated-default-style';
		
		wp_enqueue_style( 'nigiri-elated-child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ) );
	}
	
	add_action( 'wp_enqueue_scripts', 'nigiri_elated_child_theme_enqueue_scripts' );
}