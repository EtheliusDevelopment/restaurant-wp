<?php

nigiri_elated_get_module_template_part('templates/parts/image', 'blog', '', $params);
nigiri_elated_get_module_template_part('templates/parts/post-type/audio', 'blog', '', $params);