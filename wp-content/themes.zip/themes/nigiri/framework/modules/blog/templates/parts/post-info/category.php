<div class="eltdf-post-info-category">
    <?php the_category(', '); ?>
</div>